export interface User {
  id: number;
  email: string;
  nick: string;
}
